<?php $__env->startSection('title','Home page - Todo List'); ?>
<?php $__env->startSection('content'); ?>
<style>
    body
    {
        background-color:#90ee90;
    }
</style>
<div>
<div class="container">
    <div>
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Success :</strong> <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Error :</strong> <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
      </div>

    <h3 class="text-center text-primary mt-3">Todo List
    <a href="<?php echo e(route('todos.create')); ?>" class="float-end btn btn-primary">Create</a>
    </h3>

    <?php if(count($todos)==0): ?>
    <div class="alert alert-danger">
        <strong>Error :</strong> No records found
    </div>
    <?php endif; ?>
    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-3">
        <div class="card-body">
            <h4><?php echo e($todo->title); ?></h4>
            <p><?php echo e($todo->description); ?></p>
            <table>
                <tr>
                    <td> <a href="<?php echo e(route('todos.edit',$todo)); ?>" class="btn btn-success">Edit</a></td>
                    <td>
                        <form method="post" action="<?php echo e(route('todos.destroy',$todo)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            </table>


        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\todo-app\resources\views/todo/index.blade.php ENDPATH**/ ?>