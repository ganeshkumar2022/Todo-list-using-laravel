<?php $__env->startSection('title','Home page - Todo List'); ?>
<?php $__env->startSection('content'); ?>
<div style="background-color:#00bfff;height:100vh;">
    <div class="container">
        <br><br>
        <br>
        <div class="row">
            <div class="col-md-6 offset-3">

        <div class="card">
            <div class="card-body">
    <h3 class="text-center text-primary">Edit Todo</h3>
    <form action="<?php echo e(route('todos.update',$todo)); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3 mt-3">
          <label for="title" class="form-label">Title:</label>
          <input type="text" class="form-control" id="title" placeholder="Enter title" value="<?php echo e($todo->title); ?>" name="title">
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description:</label>
          <textarea rows="5" class="form-control" name="description" id="description" placeholder="Enter Description"><?php echo e($todo->description); ?></textarea>
          <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
    </div>
</div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\todo-app\resources\views/todo/edit.blade.php ENDPATH**/ ?>