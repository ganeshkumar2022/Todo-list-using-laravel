@extends('layout.app')
@section('title','Home page - Todo List')
@section('content')
<div style="background-color:#00bfff;height:100vh;">
    <div class="container">
        <br><br>
        <br>
        <div class="row">
            <div class="col-md-6 offset-3">

        <div class="card">
            <div class="card-body">
    <h3 class="text-center text-primary">Edit Todo</h3>
    <form action="{{ route('todos.update',$todo) }}" method="post" autocomplete="off">
        @csrf
        @method('PUT')
        <div class="mb-3 mt-3">
          <label for="title" class="form-label">Title:</label>
          <input type="text" class="form-control" id="title" placeholder="Enter title" value="{{ $todo->title }}" name="title">
          <span class="text-danger">{{ $errors->first('title') }}</span>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description:</label>
          <textarea rows="5" class="form-control" name="description" id="description" placeholder="Enter Description">{{ $todo->description }}</textarea>
          <span class="text-danger">{{ $errors->first('description') }}</span>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
    </div>
</div>
    </div>
</div>
</div>
</div>
@endsection
