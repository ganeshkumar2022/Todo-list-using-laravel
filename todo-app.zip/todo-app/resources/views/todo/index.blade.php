@extends('layout.app')
@section('title','Home page - Todo List')
@section('content')
<style>
    body
    {
        background-color:#90ee90;
    }
</style>
<div>
<div class="container">
    <div>
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Success :</strong> {{ session('success') }}
        </div>
        @endif
        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Error :</strong> {{ session('error') }}
        </div>
        @endif
      </div>

    <h3 class="text-center text-primary mt-3">Todo List
    <a href="{{ route('todos.create') }}" class="float-end btn btn-primary">Create</a>
    </h3>

    @if (count($todos)==0)
    <div class="alert alert-danger">
        <strong>Error :</strong> No records found
    </div>
    @endif
    @foreach ($todos as $todo)
    <div class="card mt-3">
        <div class="card-body">
            <h4>{{ $todo->title }}</h4>
            <p>{{ $todo->description }}</p>
            <table>
                <tr>
                    <td> <a href="{{ route('todos.edit',$todo) }}" class="btn btn-success">Edit</a></td>
                    <td>
                        <form method="post" action="{{ route('todos.destroy',$todo) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            </table>


        </div>
    </div>
    @endforeach
</div>
</div>
@endsection
